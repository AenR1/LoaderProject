﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.ChromeThemeContainer1 = New AimTrack_Loader.ChromeThemeContainer()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.ChromeButton5 = New AimTrack_Loader.ChromeButton()
        Me.ChromeButton4 = New AimTrack_Loader.ChromeButton()
        Me.ChromeButton1 = New AimTrack_Loader.ChromeButton()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.ChromeThemeContainer1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Timer1
        '
        '
        'ChromeThemeContainer1
        '
        Me.ChromeThemeContainer1.BackColor = System.Drawing.Color.White
        Me.ChromeThemeContainer1.BorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.ChromeThemeContainer1.Controls.Add(Me.Label13)
        Me.ChromeThemeContainer1.Controls.Add(Me.Label12)
        Me.ChromeThemeContainer1.Controls.Add(Me.Label11)
        Me.ChromeThemeContainer1.Controls.Add(Me.TextBox1)
        Me.ChromeThemeContainer1.Controls.Add(Me.ChromeButton5)
        Me.ChromeThemeContainer1.Controls.Add(Me.ChromeButton4)
        Me.ChromeThemeContainer1.Controls.Add(Me.ChromeButton1)
        Me.ChromeThemeContainer1.Controls.Add(Me.Label6)
        Me.ChromeThemeContainer1.Controls.Add(Me.Label5)
        Me.ChromeThemeContainer1.Controls.Add(Me.Label3)
        Me.ChromeThemeContainer1.Controls.Add(Me.Label2)
        Me.ChromeThemeContainer1.Controls.Add(Me.Label1)
        Me.ChromeThemeContainer1.Controls.Add(Me.ListBox1)
        Me.ChromeThemeContainer1.Customization = "AAAA/1paWv9ycnL/"
        Me.ChromeThemeContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ChromeThemeContainer1.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ChromeThemeContainer1.Image = Nothing
        Me.ChromeThemeContainer1.Location = New System.Drawing.Point(0, 0)
        Me.ChromeThemeContainer1.Movable = True
        Me.ChromeThemeContainer1.Name = "ChromeThemeContainer1"
        Me.ChromeThemeContainer1.NoRounding = False
        Me.ChromeThemeContainer1.Sizable = False
        Me.ChromeThemeContainer1.Size = New System.Drawing.Size(608, 497)
        Me.ChromeThemeContainer1.SmartBounds = True
        Me.ChromeThemeContainer1.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultLocation
        Me.ChromeThemeContainer1.TabIndex = 0
        Me.ChromeThemeContainer1.Text = "AimTrack Loader"
        Me.ChromeThemeContainer1.TransparencyKey = System.Drawing.Color.Fuchsia
        Me.ChromeThemeContainer1.Transparent = False
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.Wheat
        Me.Label13.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label13.Location = New System.Drawing.Point(69, 453)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(467, 20)
        Me.Label13.TabIndex = 21
        Me.Label13.Text = "Hileleri Çalıştırmadan Önce Lütfen Güncelleme Kontrolü Yapınız!!!"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(431, 386)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(123, 20)
        Me.Label12.TabIndex = 20
        Me.Label12.Text = "Kullanılan Sürüm:"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(173, 315)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(118, 20)
        Me.Label11.TabIndex = 19
        Me.Label11.Text = "AimTrack Cheats"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(415, 409)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.ReadOnly = True
        Me.TextBox1.Size = New System.Drawing.Size(156, 27)
        Me.TextBox1.TabIndex = 14
        Me.TextBox1.Text = "V1.0"
        '
        'ChromeButton5
        '
        Me.ChromeButton5.Customization = "7e3t//Ly8v/r6+v/5ubm/+vr6//f39//p6en/zw8PP8UFBT/gICA/w=="
        Me.ChromeButton5.Enabled = False
        Me.ChromeButton5.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ChromeButton5.Image = Nothing
        Me.ChromeButton5.Location = New System.Drawing.Point(415, 352)
        Me.ChromeButton5.Name = "ChromeButton5"
        Me.ChromeButton5.NoRounding = False
        Me.ChromeButton5.Size = New System.Drawing.Size(156, 31)
        Me.ChromeButton5.TabIndex = 13
        Me.ChromeButton5.Text = "Programı Güncelle"
        Me.ChromeButton5.Transparent = False
        '
        'ChromeButton4
        '
        Me.ChromeButton4.Customization = "7e3t//Ly8v/r6+v/5ubm/+vr6//f39//p6en/zw8PP8UFBT/gICA/w=="
        Me.ChromeButton4.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ChromeButton4.Image = Nothing
        Me.ChromeButton4.Location = New System.Drawing.Point(415, 315)
        Me.ChromeButton4.Name = "ChromeButton4"
        Me.ChromeButton4.NoRounding = False
        Me.ChromeButton4.Size = New System.Drawing.Size(156, 31)
        Me.ChromeButton4.TabIndex = 12
        Me.ChromeButton4.Text = "Güncellemeri Tara"
        Me.ChromeButton4.Transparent = False
        '
        'ChromeButton1
        '
        Me.ChromeButton1.Customization = "7e3t//Ly8v/r6+v/5ubm/+vr6//f39//p6en/zw8PP8UFBT/gICA/w=="
        Me.ChromeButton1.Enabled = False
        Me.ChromeButton1.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ChromeButton1.Image = Nothing
        Me.ChromeButton1.Location = New System.Drawing.Point(415, 280)
        Me.ChromeButton1.Name = "ChromeButton1"
        Me.ChromeButton1.NoRounding = False
        Me.ChromeButton1.Size = New System.Drawing.Size(156, 31)
        Me.ChromeButton1.TabIndex = 9
        Me.ChromeButton1.Text = "Hileye Geç"
        Me.ChromeButton1.Transparent = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(173, 345)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(162, 20)
        Me.Label6.TabIndex = 6
        Me.Label6.Text = "AimTrack Coding Team"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(30, 345)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(125, 20)
        Me.Label5.TabIndex = 5
        Me.Label5.Text = "Hilenin Yapımcısı:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(39, 315)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(116, 20)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Hilenin Durumu:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(173, 285)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(118, 20)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "AimTrack Cheats"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(69, 285)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(86, 20)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Hilenin Adı:"
        '
        'ListBox1
        '
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.ItemHeight = 20
        Me.ListBox1.Items.AddRange(New Object() {"AimTrack Wolfteam Cheat", "AimTrack Counter-Strike: Global Offensive Cheat", "AimTrack Rules Of Survival Cheat"})
        Me.ListBox1.Location = New System.Drawing.Point(12, 36)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(584, 224)
        Me.ListBox1.TabIndex = 0
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(608, 497)
        Me.Controls.Add(Me.ChromeThemeContainer1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form1"
        Me.Text = "AimTrack Loader"
        Me.TransparencyKey = System.Drawing.Color.Fuchsia
        Me.ChromeThemeContainer1.ResumeLayout(False)
        Me.ChromeThemeContainer1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents ChromeThemeContainer1 As ChromeThemeContainer
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents ChromeButton5 As ChromeButton
    Friend WithEvents ChromeButton4 As ChromeButton
    Friend WithEvents ChromeButton1 As ChromeButton
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents ListBox1 As ListBox
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Timer1 As Timer
End Class
