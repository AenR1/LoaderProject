﻿'This Loader Codded By AenR
'Please Don't Remove This Message
Public Class Form1

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox1.SelectedIndexChanged
        If ListBox1.Text = "AimTrack Wolfteam Cheat" Then
            Label2.Text = "Wolfteam"
            Label11.Text = "Updating..."
            Label11.ForeColor = Color.Gold
        End If
        If ListBox1.Text = "AimTrack Counter-Strike: Global Offensive Cheat" Then
            Label2.Text = "CS:GO"
            Label11.Text = "Updating..."
            Label11.ForeColor = Color.Gold
        End If
        If ListBox1.Text = "AimTrack Rules Of Survival Cheat" Then
            Label2.Text = "RoS"
            Label11.Text = "Updating..."
            Label11.ForeColor = Color.Gold
        End If
    End Sub

    Private Sub ChromeButton1_Click(sender As Object, e As EventArgs) Handles ChromeButton1.Click
        If ListBox1.Text = "AimTrack Wolfteam Cheat" Then
            wt.Show()
            Me.Hide()
        End If
        If ListBox1.Text = "AimTrack Counter-Strike: Global Offensive Cheat" Then
            csgo.Show()
            Me.Hide()
        End If
        If ListBox1.Text = "AimTrack Rules Of Survival Cheat" Then
            ros.Show()
            Me.Hide()
        End If
    End Sub

    Private Sub ChromeButton3_Click(sender As Object, e As EventArgs)
        MessageBox.Show("V1.0")
    End Sub

    Private Sub ChromeButton4_Click(sender As Object, e As EventArgs) Handles ChromeButton4.Click
        If TextBox1.Text = "V1.0" Then
            MessageBox.Show("Programınız Günceldir.")
            ChromeButton1.Enabled = True
        Else
            MessageBox.Show("Programı Lütfen Güncelleyiniz.")
            ChromeButton5.Enabled = True
        End If
    End Sub

    Private Sub ChromeButton5_Click(sender As Object, e As EventArgs) Handles ChromeButton5.Click
        Process.Start("https://github.com/aenr/AimTrackLoader/blob/master/AimTrackLoader.exe?raw=true")
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Dim client As New Net.WebClient
        TextBox1.Text = client.DownloadString("https://raw.githubusercontent.com/aenr/AimTrackLoader/master/surum.txt")
    End Sub
End Class
