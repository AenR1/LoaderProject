﻿Public Class Form1

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Label2.Hide()
        Label8.Hide()
        Label9.Hide()
        Label4.Hide()
        Label7.Hide()
    End Sub
    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox1.SelectedIndexChanged
        If ListBox1.Text = "AimTrack Wolfteam Cheat" Then
            Label8.Visible = False
            Label9.Visible = False
            Label2.Visible = True
            Label10.Visible = False
            Label4.Visible = False
            Label11.Visible = False
            Label7.Visible = True
        End If
        If ListBox1.Text = "AimTrack Counter-Strike: Global Offensive Cheat" Then
            Label8.Visible = True
            Label9.Visible = False
            Label2.Visible = False
            Label10.Visible = False
            Label4.Visible = False
            Label11.Visible = False
            Label7.Visible = True
        End If
        If ListBox1.Text = "AimTrack Rules Of Survival Cheat" Then
            Label8.Visible = False
            Label9.Visible = True
            Label2.Visible = False
            Label10.Visible = False
            Label4.Visible = False
            Label11.Visible = False
            Label7.Visible = True
        End If
    End Sub

    Private Sub ChromeButton1_Click(sender As Object, e As EventArgs) Handles ChromeButton1.Click
        If ListBox1.Text = "AimTrack Wolfteam Cheat" Then
            wt.Show()
            Me.Hide()
        End If
        If ListBox1.Text = "AimTrack Counter-Strike: Global Offensive Cheat" Then
            csgo.Show()
            Me.Hide()
        End If
        If ListBox1.Text = "AimTrack Rules Of Survival Cheat" Then
            ros.Show()
            Me.Hide()
        End If
    End Sub

    Private Sub ChromeButton3_Click(sender As Object, e As EventArgs) Handles ChromeButton3.Click
        MessageBox.Show("V1.0")
    End Sub

    Private Sub ChromeButton4_Click(sender As Object, e As EventArgs) Handles ChromeButton4.Click
        If TextBox1.Text = "V1.0" Then
            MessageBox.Show("Programınız Günceldir.")
        Else
            MessageBox.Show("Programı Lütfen Güncelleyiniz.")
            ChromeButton5.Enabled = True
        End If
    End Sub

    Private Sub ChromeButton5_Click(sender As Object, e As EventArgs) Handles ChromeButton5.Click
        Process.Start("https://github.com/aenr/AimTrackLoader/blob/master/AimTrackLoader.exe?raw=true")
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Dim client As New Net.WebClient
        TextBox1.Text = client.DownloadString("https://raw.githubusercontent.com/aenr/AimTrackLoader/master/surum.txt")
    End Sub
End Class
